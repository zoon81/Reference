#include "main.h"
#include <avr/sleep.h>
#include <avr/interrupt.h>
#include "light_ws2812.h"
#include "adc.h"
#include "eeprom_api.h"

#define EEPROM_ADDR_COLOR_INDEX         0x00
#define EEPROM_ADDR_BRIGTNESS_INDEX     0x01

#define PIXELS 8

#define COLOR_R 128;
#define COLOR_G 0;
#define COLOR_B 0;

#define COLORS          6
#define COLOR_RED       {255,0,0}
#define COLOR_GREEN     {0,255,0}
#define COLOR_BLUE      {0,0,255}
#define COLOR_ORANGE    {0xff,0x1f,0}
#define COLOR_YELLOW    {0xff,0x6f,0}
#define COLOR_PURPLE    {143,0,255}
#define COLOR_LIGHT_BLUE    {0x00,0x85,0x98}
#define COLOR_OFF       {0,0,0}

struct pixel {
	uint8_t r;
	uint8_t g;
	uint8_t b;
};

enum btn_press_duration{
    BTN_PRESS_DURATION_SHORT,
    BTN_PRESS_DURATION_LONG,
    BTN_PRESS_DURATION_UNDEFINED
};

enum colormap_index{
    MCOLORMAP_RED,
    MCOLORMAP_GREEN,
    MCOLORMAP_BLUE,
    MCOLORMAP_ORANGE,
    MCOLORMAP_YELLOW,
    MCOLORMAP_PURPLE,
    MCOLORMAP_LEN
};

enum status_bar_direction{
    STATUS_BAR_DIRECTION_NORMAL,
    STATUS_BAR_DIRECTION_REVERSE
};

void activate_sleep_mode();
enum btn_press_duration usr_input_read();
void showProgressBar(uint8_t progress, enum colormap_index colorIndex);
void setAllLedColor(uint8_t r, uint8_t g, uint8_t b);
void setLedColors(const struct pixel *p, uint8_t led_number);
void updateLedColors();
void setAndUpdateLedColor(const struct pixel *p, uint8_t led_number);
void startLEDs(enum colormap_index colorIndex);
void stopLEDs();
uint8_t applyBrigthnessLevel(uint8_t color_value);
void setBrigthnessByLevel(uint8_t brigness_level);

struct pixel mPixels[PIXELS]={0};
const struct pixel mColorMap[6] = 
        {COLOR_RED, COLOR_GREEN, COLOR_BLUE,
        COLOR_ORANGE, COLOR_YELLOW, COLOR_PURPLE
    };
enum colormap_index mColorIndex = MCOLORMAP_RED;
uint8_t mBrigthness_level;
volatile uint8_t status;

void main(void)
{
    ENABLE_LED_DRV;
    ENABLE_LED_PWR;

    status = STATUS_IDLE;
    mBrigthness_level = 50;
    setAllLedColor(0, 0, 0);
    setAndUpdateLedColor(&(const struct pixel) COLOR_GREEN, 0);
    _delay_ms(1000);
    setAllLedColor(0, 0, 0);
    uint8_t chrg_anim_state = 0;
    uint8_t brigness_level = 1;

    //LOAD CFG from EEPROM
    mColorIndex = EEPROM_read(EEPROM_ADDR_COLOR_INDEX);
    if(mColorIndex >= MCOLORMAP_LEN){
        mColorIndex = 0;
    }
    brigness_level = EEPROM_read(EEPROM_ADDR_BRIGTNESS_INDEX);
    if(brigness_level > 5){
        brigness_level = 1;
    }
    setBrigthnessByLevel(brigness_level);
	/* loop */
	while (1) {
        // Check for user BTN
        if( !(PINB & (1 << USR_BTN_INPUT)) && status != STATUS_CHRG){
            // Short press will show the battery SoC
            adc_init();
            uint16_t battery_voltage = adc_getVcc();
            enum colormap_index colormap_index = mColorIndex;
            if(battery_voltage <= 3400){
                mColorIndex =  MCOLORMAP_RED;
            } else if(battery_voltage <= 4000){
                mColorIndex =  MCOLORMAP_YELLOW;
            } else {
                mColorIndex =  MCOLORMAP_GREEN;
            }
            enum btn_press_duration press_kind = usr_input_read();
            mColorIndex =  colormap_index;
            adc_deinit();
            // Press should be  between 2 and 4 sec
            if(press_kind == BTN_PRESS_DURATION_SHORT){
                // USR BTN PRESS ACTION
                if(status == STATUS_IDLE){
                    // Start LEDs
                    startLEDs(mColorIndex);
                    status = STATUS_LEDON;
                } else if (status == STATUS_LEDON){
                    stopLEDs();
                    status = STATUS_IDLE;
                }
            } else if(press_kind == BTN_PRESS_DURATION_LONG){
                // Color select mode
                mColorIndex = 0;
                status = STATUS_SETUP;
                enum btn_press_duration press_kind = BTN_PRESS_DURATION_SHORT;
                while( press_kind != BTN_PRESS_DURATION_LONG){
                    press_kind = usr_input_read();
                    startLEDs(mColorIndex);
                    if(press_kind == BTN_PRESS_DURATION_SHORT){
                        mColorIndex++;
                        if(mColorIndex >= COLORS){
                            mColorIndex = 0;
                        }
                        startLEDs(mColorIndex);
                    }
                    _delay_ms(300);
                }
                status = STATUS_LEDON;
                startLEDs(mColorIndex);
                // Store color index
                EEPROM_write(EEPROM_ADDR_COLOR_INDEX, mColorIndex);
                // Brigtness select mode
                press_kind = BTN_PRESS_DURATION_SHORT;
                while( press_kind != BTN_PRESS_DURATION_LONG){
                    press_kind = usr_input_read();
                    startLEDs(mColorIndex);
                    if(press_kind == BTN_PRESS_DURATION_SHORT){
                        brigness_level += 1;
                        if(brigness_level > 6){
                            brigness_level = 1;
                        }
                        setBrigthnessByLevel(brigness_level);
                        startLEDs(mColorIndex);
                    }
                    _delay_ms(300);
                }
                // Store brigness value
                EEPROM_write(EEPROM_ADDR_BRIGTNESS_INDEX, brigness_level);
            }
        }
        // Charge handling
        if( !(PINB & (1 << CHRG_STATE_IN)) ){
            if(status == STATUS_IDLE){
                //adc_init();
                ENABLE_LED_DRV;
                ENABLE_LED_PWR;
                status = STATUS_CHRG;
                chrg_anim_state = 0;
            }
            // uint16_t battery_voltage = adc_getVcc();
            // Charge animation, we can not measure battery voltage during charge
            // MCU powered from external Vin (5v) during charge
            showProgressBar(chrg_anim_state, MCOLORMAP_GREEN);
            chrg_anim_state = chrg_anim_state + 25 > 100 ? 0: chrg_anim_state + 25;
            // setAndUpdateLedColor(&(const struct pixel) COLOR_PURPLE, 0);
            _delay_ms(1000);
        } else if(status == STATUS_CHRG){
            //adc_deinit();
            setAllLedColor(0,0,0);
            status = STATUS_IDLE;
        }
        // Cut of LEDs if we are in idle mode to save power
        if(status == STATUS_IDLE){
            DISABLE_LED_PWR;
            DISABLE_LED_DRV;
        }
        // Go sleep if the cpu are done
        if(status != STATUS_CHRG){
            activate_sleep_mode();
        }
    }
}

void activate_sleep_mode(){
    GIMSK |= (1 << PCIE);
    PCMSK |= (1 << PCINT1) | (1 << PCINT0);
    sei();
    set_sleep_mode(SLEEP_MODE_PWR_DOWN);
    sleep_mode();
}

enum btn_press_duration usr_input_read(){
    ENABLE_LED_DRV;
    ENABLE_LED_PWR;
    volatile uint8_t cntr = 0;
    enum colormap_index color_index;
    enum colormap_index longpress_colorIndex;

    if(status == STATUS_SETUP){
        color_index = mColorIndex + 1 == MCOLORMAP_LEN ? 0 : mColorIndex + 1;
        longpress_colorIndex = mColorIndex;
    } else {
        color_index = mColorIndex;
        longpress_colorIndex = mColorIndex + 1 == MCOLORMAP_LEN ? 0 : mColorIndex + 1;
    }

    while( !(PINB & (1 << USR_BTN_INPUT)) && cntr < USR_BTN_TRIGGER_MAX){
        cntr++;
        // Proggress bar of btn press
        switch (cntr){
            case 10:
                if(status == STATUS_LEDON){
                    setAndUpdateLedColor( &(const struct pixel) COLOR_OFF, 3);
                } else {
                    showProgressBar(25, color_index);
                }
                break;
            case 15:
                if(status == STATUS_LEDON){
                    setAndUpdateLedColor( &(const struct pixel) COLOR_OFF, 2);
                } else {
                    showProgressBar(50, color_index);
                }
                break;
            case 20:
                if(status == STATUS_LEDON){
                    setAndUpdateLedColor( &(const struct pixel) COLOR_OFF, 1);
                } else {
                    showProgressBar(75, color_index);
                }
                break;
            case 25:
                if(status == STATUS_LEDON){
                    setAndUpdateLedColor( &(const struct pixel) COLOR_OFF, 0);
                } else {
                    showProgressBar(100, color_index);
                }
                break;
            case 40:
                setAllLedColor(0,0,0);
                break;
            case 50:
                showProgressBar(25, longpress_colorIndex);
                break;
            case 60:
                showProgressBar(50, longpress_colorIndex);
                break;
            case 75:
                showProgressBar(75, longpress_colorIndex);
                break;
            case 85:
                showProgressBar(100, longpress_colorIndex);
                break;
            case 95:
                setAllLedColor(0,0,0);
                break;
            default:
                break;
            }
        _delay_ms(75);
    }
    // Press should be between 2 and 4 sec
    if(cntr >= USR_BTN_TRIGGER_PRESS && cntr < USR_BTN_TRIGGER_LONGPRESS - 40){
        // USR BTN PRESS ACTION
        return BTN_PRESS_DURATION_SHORT;
        } else if(cntr >= USR_BTN_TRIGGER_LONGPRESS - 20 && cntr < USR_BTN_TRIGGER_LONGPRESS + 20){
            return BTN_PRESS_DURATION_LONG;
        } else {
            return BTN_PRESS_DURATION_UNDEFINED;
        }
}

void showProgressBar(uint8_t progress, enum colormap_index colorIndex){
    switch (progress)
    {
    case 0:
        setAllLedColor(0,0,0);
        break;
    case 25:
        setAndUpdateLedColor( &mColorMap[colorIndex], 0 );
        break;
    case 50:
        setAndUpdateLedColor( &mColorMap[colorIndex], 1 );
        break;
    case 75:
        setAndUpdateLedColor( &mColorMap[colorIndex], 2 );
        break;
    case 100:
        setAndUpdateLedColor( &mColorMap[colorIndex], 3 );
        break;
    default:
        break;
    }
}

void startLEDs(enum colormap_index colorIndex){
    ENABLE_LED_PWR;
    _delay_ms(10);
    ENABLE_LED_DRV;
    setAllLedColor(
        applyBrigthnessLevel( mColorMap[colorIndex].r ),
        applyBrigthnessLevel( mColorMap[colorIndex].g ),
        applyBrigthnessLevel( mColorMap[colorIndex].b )
    );
}

void stopLEDs(){
    setAllLedColor(0, 0, 0);
}

void setAllLedColor(uint8_t r, uint8_t g, uint8_t b){
    uint8_t i = PIXELS;
    while(i--){
        mPixels[i].r = r;
        mPixels[i].g = g;
        mPixels[i].b = b;
    }
    updateLedColors();
}

void setLedColors(const struct pixel *p, uint8_t led_number){
    mPixels[led_number].r = applyBrigthnessLevel(p->r);
    mPixels[led_number].g = applyBrigthnessLevel(p->g);
    mPixels[led_number].b = applyBrigthnessLevel(p->b);
}

void updateLedColors(){
    uint8_t cntr = 0;
    struct cRGB led_array[PIXELS];
    while(cntr < PIXELS){
        led_array[cntr].r = mPixels[cntr].r;
        led_array[cntr].g = mPixels[cntr].g;
        led_array[cntr].b = mPixels[cntr].b;
        cntr++;
    }
    ws2812_setleds(&led_array, (uint16_t) PIXELS);
}

void setAndUpdateLedColor(const struct pixel *p, uint8_t led_number){
    setLedColors(p, led_number);
    updateLedColors();
}

uint8_t applyBrigthnessLevel(uint8_t color_value){
    return (uint8_t) ((double) color_value / (double) 100 * (double) mBrigthness_level);
}

void setBrigthnessByLevel(uint8_t brigness_level)
{
    switch (brigness_level)
    {
    case 1:
        mBrigthness_level = 20;
        break;
    case 2:
        mBrigthness_level = 35;
        break;
    case 3:
        mBrigthness_level = 50;
        break;
    case 4:
        mBrigthness_level = 65;
        break;
    case 5:
        mBrigthness_level = 100;
        break;
    default:
        break;
    }
}

ISR(PCINT0_vect) {
    // Device wake up
}