#include <stdbool.h>

#include "stm32f1xx_hal.h"
#include "gpio.h"
#include "spi.h"
#include "fatfs.h"
#include "eeprom.h"
#include "nrf24.h"
#include "led_driver.h"
#include "led_conf.h"

#define DEVICE_STATUS_CONNECTED     0x01
#define DEVICE_STATUS_PLAYING       0x02
#define DEVICE_STATUS_DISCONNECTED  0x03
#define DEVICE_STATUS_FAIL          0x13  
#define DEVICE_STATUS_PAIRING       0x15

#define STORAGE_RADIO0_ADDR                 0x00
#define STORAGE_RADIO1_ADDR                 0x01
#define STORAGE_RADIO2_ADDR                 0x02
#define STORAGE_RADIO3_ADDR                 0x03
#define STORAGE_RADIO4_ADDR                 0x04
#define STORAGE_HAS_STOREG_RADIO_DATA_ADDR  0x05
#define STORAGE_HAS_STOREG_RADIO_DATA       0xFEED

#define RADIO_CMD_BROADCAST_START   1
#define RADIO_CMD_BROADCAST_STOP    2

// R1 1k5 and R2 5k1 so the ratio is about 0.773
#define ADC_VOLTAGE_DIVIDER_RATIO (5.1 / 6.6)
#define VOLTAGE_DROP_TRESHOLD 0.3


// File management
FATFS fs;
FATFS *pfs;
FIL fil_video;
FIL fil_back;
FRESULT fres;

// ADC
static void MX_ADC1_Init(void);
ADC_HandleTypeDef hadc1;

// EEPROM STUFF
#define NM_OF_VAR ((uint8_t)0x06)
uint16_t VirtAddVarTab[NM_OF_VAR] = { STORAGE_HAS_STOREG_RADIO_DATA_ADDR, STORAGE_RADIO0_ADDR,  STORAGE_RADIO1_ADDR,  STORAGE_RADIO2_ADDR,  STORAGE_RADIO3_ADDR,  STORAGE_RADIO4_ADDR };

// Functions
void _Error_Handler(char *, int);
void app_error_handler(uint8_t error_code);
static void SystemClock_Config(void);
bool radioLoadStoredAddress();
void radioStoreAddreess(uint8_t *radio_address);
uint32_t __getElapsedTime(uint32_t time_from);
void led_driver_eof_callback();
double adc_sample();

// IRQ Callbacks
void nrf_irq_callback();
void sync_pressed_callback();
void external_play_req_callback();

// Flags
volatile bool hasNewData_p0;
volatile bool is_rc_online;
volatile bool playing_video1;
volatile bool playing_video2;
volatile bool playing_video1_finished;
volatile bool playing_video2_finished;
volatile bool resync_pressed;
volatile bool button_din1_pressed;
volatile bool button_din2_pressed;
volatile bool start_tim3;
volatile bool stop_tim3;

uint8_t device_status;

// General variables
uint32_t button_din1_elapsed_time;
uint32_t button_din2_elapsed_time;
uint32_t sync_packet_income_time;
payload_t payload;


int main(void)
{
  HAL_Init();
  // Configure the system clock to 64 MHz
  SystemClock_Config();
  // RCC->APB2ENR |= RCC_APB2ENR_AFIOEN;
  MX_GPIO_Init();
  CLEAR_BIT(DBGMCU->CR, DBGMCU_CR_TRACE_IOEN);
  afio_cfg_debug_ports(AFIO_DEBUG_SW_ONLY);
  HAL_GPIO_WritePin(NRF_CONTROL_PORT, NRF_CE_PIN, GPIO_PIN_RESET);

  MX_SPI1_Init();
  MX_SPI2_Init();
  MX_FATFS_Init();
  MX_ADC1_Init();
  HAL_FLASH_Unlock();
  EE_Init();

  resync_pressed = false;
  playing_video1 = false;
  playing_video2 = false;
  playing_video1_finished = false;
  playing_video2_finished = false;
  is_rc_online = false;
  hasNewData_p0 = false;
  start_tim3 = false;
  start_tim3 = false;
  
  // Init radio
  nrf24_Init();
  nrf24_status_clearInterupts();
  nrf24_flushRX();
  nrf24_flushTX();
  if(radioLoadStoredAddress()){
    // No stored address yet, go to save some power and waiting for sync btn press
    nrf24_stopReceiver();
    device_status = DEVICE_STATUS_DISCONNECTED;
  } else  {
    nrf24_startReceiver();
    nrf24_enableBroadCastPipe();
    HAL_NVIC_EnableIRQ(EXTI3_IRQn);
    device_status = DEVICE_STATUS_CONNECTED;
  }


  // SD-Card must be formated as FAT_32 with 2048 Allocation Block Size
  if(f_mount(&fs, "", 0) != FR_OK){
    app_error_handler(ERROR_MOUNT_FAILED);
  }
  if(f_open(&fil_video, FILENAME_VIDEO, FA_READ) != FR_OK){
    app_error_handler(ERROR_VIDEO_FILE_NOT_FOUND);
  }
  if(f_open(&fil_back, FILENAME_BACK, FA_READ) != FR_OK){
    app_error_handler(ERROR_BACK_FILE_NOT_FOUND);
  }
  HAL_ADC_Start(&hadc1);
  double open_voltage = adc_sample();

  led_driver_Init();
  led_driver_setFileObject(&fil_video);
  led_driver_setEOFCallback( &led_driver_eof_callback );
  led_driver_setAllLedColor(255, 0, 0);
  double loaded_voltage = adc_sample();
  while(led_driver_isBusy());
  HAL_Delay(2000);
  led_driver_setAllLedColor(0, 0, 0);
  while(led_driver_isBusy());
  // preload first frame
  led_driver_updateFrameBuffer();
  if((open_voltage - loaded_voltage) > VOLTAGE_DROP_TRESHOLD){
    app_error_handler(ERROR_BATTERY_LOW);
  }
  GPIO_InitTypeDef gpio;
  gpio.Mode = GPIO_MODE_OUTPUT_PP;
  gpio.Pin = GPIO_PIN_15;
  gpio.Pull = GPIO_NOPULL;
  gpio.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(GPIOC, &gpio);

  volatile uint32_t value;

  while (1)
  {
    // HAL_ADC_PollForConversion (&hadc1, 1000);
    // value = HAL_ADC_GetValue (&hadc1);
    value = 0;
    if (hasNewData_p0){
      hasNewData_p0 = false;
      switch (payload.command){
      case RADIO_CMD_PAIR:{
        RadioAddress_t paired_addr = BASE_ADDRESS;
        paired_addr.addr1 += payload.data1; // Data1 hold the offset from BASE_ADDRESS
        radioStoreAddreess((uint8_t *)&paired_addr);
        nrf24_setRxAddressPipe0((uint8_t *)&paired_addr);
        nrf24_enableBroadCastPipe();
        nrf24_stopReceiver();
        HAL_Delay(1);
        nrf24_startReceiver();
        HAL_Delay(1);
        device_status = DEVICE_STATUS_CONNECTED;
        break;
      }
      case RADIO_CMD_STATUS:
        // We have 130ms until the PRX send back the ACK, so if we are not playing, we can fill up before the ACK goes back
        // If we are playing, we are much slower, and the fillup will be out of this 130ms windows, so the response will be
        // send at the next (for example ping) packet.
        payload.header = 0;
        payload.command = RADIO_CMD_STATUS;
        payload.data1 = device_status;
        // TODO: ADC value
        payload.data2 = 0;
        payload.data3 = 0;
        nrf24_setTxPayload((uint8_t *)&payload);
        break;
      case RADIO_CMD_PING:
        nrf24_disableFeatures();
        nrf24_setPayloadLength(0, 5);
        break;
      case RADIO_CMD_SYNC:{
        // We will start playing from the time from the RC + 2 sec
        uint32_t elapsed_sec = payload.data1;
        elapsed_sec = elapsed_sec * 60;
        elapsed_sec += payload.data2;
        elapsed_sec += 1;
        // We doing the frame update with 62 FPS
        uint32_t start_frame_num = elapsed_sec * 62;
        uint32_t file_pos = start_frame_num * BYTES_PER_FRAME;
        f_lseek(&fil_video, file_pos);
        led_driver_updateFrameBuffer();
        uint32_t elapsed_time_util_sync;
        do{
          elapsed_time_util_sync = __getElapsedTime(sync_packet_income_time);
        } while (elapsed_time_util_sync < 1020);
        playing_video1 = true;
        device_status =  DEVICE_STATUS_PLAYING;
        led_driver_begin();
        break;
      }
      default:
        break;
      }
    }
    // Pairing not allowed during play
    if (resync_pressed && !playing_video1 && !playing_video2){
      // Sync Pressed, set address, start receiver and enable interrupt
      nrf24_stopReceiver();
      HAL_Delay(10);
      RadioAddress_t addr = UNPAIRED_NODE_ADDRESS;
      nrf24_setRxAddressPipe0((uint8_t *)&addr);
      HAL_Delay(10);
      nrf24_startReceiver();
      nrf24_status_clearInterupts();
      nrf24_flushTX();
      nrf24_flushRX();
      HAL_NVIC_EnableIRQ(EXTI3_IRQn);
      resync_pressed = false;
      device_status = DEVICE_STATUS_PAIRING;
    }

    if (start_tim3){
      led_driver_begin();
      start_tim3 = false;
    }

    if (stop_tim3){
      led_driver_stop();
      stop_tim3 = false;
    }

    if (!is_rc_online){
      // If we can't access the rc, remove the status response from FiFo if any
      // radio.flushTxFiFo();
      // radio.flushRxFiFo();
    }

    if (device_status == DEVICE_STATUS_PAIRING){
      HAL_GPIO_WritePin(LED_EXTERNAL_RED_PORT, LED_EXTERNAL_RED_PIN, GPIO_PIN_SET);
      HAL_Delay(200);
      HAL_GPIO_WritePin(LED_EXTERNAL_RED_PORT, LED_EXTERNAL_RED_PIN, GPIO_PIN_RESET);
      HAL_Delay(200);
    }

    if (playing_video1){
      led_driver_handle();
    }
  }
}

// Configure 64MHz system clock. With external crystal is possible to set maximal frequency to 72MHz
static void SystemClock_Config(void){
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;
  
  /* HSI Oscillator already ON after system reset, activate PLL with HSI as source */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV2;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct)!= HAL_OK)
  {
    //Error_Handler();
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 
     clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;  
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2)!= HAL_OK)
  {
    //Error_Handler();
  }
}

bool radioLoadStoredAddress(){
  uint16_t hasStoredAddressMagic = 0;
  EE_ReadVariable(VirtAddVarTab[0], &hasStoredAddressMagic);
  if(hasStoredAddressMagic == STORAGE_HAS_STOREG_RADIO_DATA){
    uint8_t radio_address[5];
    EE_ReadVariable(VirtAddVarTab[1], (uint16_t *) &radio_address[0]);
    EE_ReadVariable(VirtAddVarTab[2], (uint16_t *) &radio_address[1]);
    EE_ReadVariable(VirtAddVarTab[3], (uint16_t *) &radio_address[2]);
    EE_ReadVariable(VirtAddVarTab[4], (uint16_t *) &radio_address[3]);
    EE_ReadVariable(VirtAddVarTab[5], (uint16_t *) &radio_address[4]);
    nrf24_setRxAddressPipe0(radio_address);
    return false;
  } else {
    return true;
  }
  
}

void radioStoreAddreess(uint8_t *radio_address){
  uint16_t magic = STORAGE_HAS_STOREG_RADIO_DATA;
  uint16_t ret = EE_WriteVariable(VirtAddVarTab[0], magic);
  ret = EE_WriteVariable(VirtAddVarTab[1], (uint16_t ) radio_address[0]);
  ret = EE_WriteVariable(VirtAddVarTab[2], (uint16_t ) radio_address[1]);
  ret = EE_WriteVariable(VirtAddVarTab[3], (uint16_t ) radio_address[2]);
  ret = EE_WriteVariable(VirtAddVarTab[4], (uint16_t ) radio_address[3]);
  ret = EE_WriteVariable(VirtAddVarTab[5], (uint16_t ) radio_address[4]);
}

void nrf_irq_callback(){
  uint8_t nrf_status = nrf24_getStatus();
  uint8_t datapipe = nrf24_status_getDataPipe(nrf_status);
  if(datapipe == 0){
    nrf24_getRXpayload((uint8_t *)&payload, 5);
    if(payload.command == RADIO_CMD_SYNC){
      sync_packet_income_time = HAL_GetTick();
    }
    hasNewData_p0 = true;
    is_rc_online = true;
  } else if(datapipe == 1){
    // Start or stop playing
    uint8_t payload;
    nrf24_getRXpayload(&payload, 1);
    if(payload == RADIO_CMD_BROADCAST_START){
      playing_video1 = true;
      start_tim3 = true;
      device_status = DEVICE_STATUS_PLAYING;
    } else if(payload == RADIO_CMD_BROADCAST_STOP){
      playing_video1 = false;
      stop_tim3 = true;
      device_status = DEVICE_STATUS_CONNECTED;
    }
    is_rc_online = true;
  }
  nrf24_status_clearInterupts();
}

void sync_pressed_callback(){
  resync_pressed = true;
}

void app_error_handler(uint8_t error_code){
  while(1){
    HAL_GPIO_WritePin(LED_EXTERNAL_RED_PORT, LED_EXTERNAL_RED_PIN, GPIO_PIN_SET);
    HAL_Delay(5000);
    uint8_t counter;
    for(counter = 0; counter < error_code; counter++){
      HAL_GPIO_WritePin(LED_EXTERNAL_RED_PORT, LED_EXTERNAL_RED_PIN, GPIO_PIN_RESET);
      HAL_Delay(500);
      HAL_GPIO_WritePin(LED_EXTERNAL_RED_PORT, LED_EXTERNAL_RED_PIN, GPIO_PIN_SET);
      HAL_Delay(500);
    }
    HAL_GPIO_WritePin(LED_EXTERNAL_RED_PORT, LED_EXTERNAL_RED_PIN, GPIO_PIN_RESET);
    HAL_Delay(2000);
  }
}

void external_DIN1_trigger(GPIO_PinState gpio_state){
  if(gpio_state){
    button_din1_elapsed_time = HAL_GetTick();
    button_din1_pressed = true;
  } else if(button_din1_pressed){
    if( __getElapsedTime(button_din1_elapsed_time) > 1000){
      playing_video1 = true;
      start_tim3 = true;
    }
  }
}

void external_DIN2_trigger(GPIO_PinState gpio_state){
  if(gpio_state){
    button_din2_elapsed_time = HAL_GetTick();
    button_din2_pressed = true;
  } else if(button_din2_pressed){
    if( __getElapsedTime(button_din2_elapsed_time) > 1000){
      playing_video2 = true;
      start_tim3 = true;
    }
  }
}

uint32_t __getElapsedTime(uint32_t time_from){
  uint32_t time_now = HAL_GetTick();
  if(time_now < time_from){
    // Systick overflow after 49 days O_o, so implement it if you want a realy long delay ;-)
  }
  return time_now - time_from;
}

void led_driver_eof_callback(){
  if(playing_video1){
    playing_video1 = false;
    playing_video1_finished = true;
    device_status = DEVICE_STATUS_CONNECTED;
  } else if (playing_video2){
    playing_video2 = false;
    playing_video2_finished = true;
    device_status = DEVICE_STATUS_CONNECTED;
  }
}

static void MX_ADC1_Init(void){
  ADC_ChannelConfTypeDef sConfig = {0};
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  HAL_ADC_Init(&hadc1);
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  HAL_ADC_ConfigChannel(&hadc1, &sConfig);
}

void HAL_ADC_MspInit(ADC_HandleTypeDef* hadc)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(hadc->Instance==ADC1)
  {
    __HAL_RCC_ADC1_CLK_ENABLE();
  
    __HAL_RCC_GPIOA_CLK_ENABLE();
    
    GPIO_InitStruct.Pin = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    HAL_NVIC_SetPriority(ADC1_2_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(ADC1_2_IRQn);
  
  }

}

double adc_sample(){
  uint32_t sample;
  uint64_t tmp = 0;
  uint8_t i;
  for(i = 0; i < 10; i++){
    HAL_ADC_PollForConversion (&hadc1, 1000);
    sample = HAL_ADC_GetValue (&hadc1);
    tmp += sample;
  }
  double raw = tmp / 10;
  volatile double voltage = ((double) 3.3 / (double) 4096) * raw;
  voltage = voltage / (ADC_VOLTAGE_DIVIDER_RATIO);  
  return voltage;
}
