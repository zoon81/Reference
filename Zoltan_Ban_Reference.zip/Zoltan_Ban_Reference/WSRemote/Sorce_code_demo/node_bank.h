#ifndef INC_NODE_BANK_H
#define INC_NODE_BANK_H

#include <stdio.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"

#define NODE_STATUS_CONNECTED       1
#define NODE_STATUS_PLAYING         2
#define NODE_STATUS_DISCONNECTED    3
#define NODE_STATUS_FAIL            6
#define NODE_STATUS_SYNC_REQ        0x21

#define NODE_ERROR_MOUNT_FAILED          0x01
#define NODE_ERROR_VIDEO_FILE_NOT_FOUND  0x02
#define NODE_ERROR_BACK_FILE_NOT_FOUND   0x03
#define NODE_ERROR_RADIO_NOT_RESPOND     0x04
#define NODE_ERROR_BATTERY_LOW           0x05

#define BATTERY_CHARGING            200
#define BATTERY_CHARGED             201
#define BATTERY_NOBATTERY           202
#define BATTERY_CHR_DISCONNECTED    203

#define NODE_NAME_MAX_LEN 12
#define NODE_MAX_NODES_COUNT 32


void        nodebank_init(void (*callback) ());
void        nodebank_addPairedNode(const char * node_name);
uint8_t     nodebank_getFreeSubAddress();
void        nodebank_setLastPairResult(bool result);
uint8_t     nodebank_getNodeSubAddresbyIndex(uint8_t node_index);
void        nodebank_setStatusRequestisSent(uint8_t node_index);
uint8_t     nodebank_getNodeCount();
uint8_t     nodebank_getStoredNodesCount();
uint8_t     nodebank_getConnectedNodeCount();
void        nodebank_selectActiveNode(uint8_t node_index);
uint8_t     nodebank_getNodeByName(char *node_name);
void        nodebank_getNodeNamebyIndex(uint8_t index, char *buffer);
bool        nodebank_isLastPairSuccess();
uint8_t     nodebank_getActiveNodeSubAddress();
void        nodebank_setActiveNodeStatus(uint8_t status);
uint8_t     nodebank_getActiveNodeStatus();
void        nodebank_setActiveNodeStatusRequestisSent(bool requestIsSent);
bool        nodebank_getActiveNodeStatusRequestisSent();
void        nodebank_setActiveNodeBatteryVoltage(uint16_t battery_voltage);
uint16_t    nodebank_getActiveNodeBatteryVoltage();
void        nodebank_setActiveNodeBatteryPercent(uint8_t battery_percent);
uint8_t     nodebank_getActiveNodeBatteryPercent();
void        nodebank_setActiveNodeSignal(uint8_t signal);
uint8_t     nodebank_getActiveNodeSignal();
void        nodebank_setActiveNodeName(char *name);
void        nodebank_getActiveNodeName(char *buffer);
void        nodebank_setActiveNodeErrorCode(uint8_t err);
uint8_t     nodebank_getActiveNodeErrorCode();
void        nodebank_deletePairedNodes();
void        nodebank_deleteNodeByIndex(uint8_t index);
void        nodebank_commitChanges();



#endif 