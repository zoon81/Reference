// Todos:
//      Symbols for virtual keyboard
//      Inactivate buttons in start/stop menu
//      Visual feedback press/release in start/stop menu

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "esp_timer.h"
#include "driver/gpio.h"
#include "driver/ledc.h"

#include "esp_heap_task_info.h"


#include "esp_freertos_hooks.h"

#include "esp_spi_flash.h"
#define LOG_LOCAL_LEVEL ESP_LOG_VERBOSE
#include <esp_log.h>
#include "driver/adc.h"
#include <math.h>
#include "freertos/queue.h"

#include "radio.h"
#include "nrf24.h"
#include "node_bank.h"
#include "rc_battery.h"
#include "ui.h"
#include "if.h"
#include "ws2812.h"

#include "drv/disp_spi.h"
#include "drv/ili9341.h"
#include "drv/tp_spi.h"
#include "drv/xpt2046.h"
#include "lvgl/lvgl.h"

#define BUTTON_L_SEL         1
#define BUTTON_BACK          2
#define BUTTON_ALT           3
#define BUTTON_ENTER         4
#define BUTTON_DOWN          5
#define BUTTON_LEFT          6
#define BUTTON_UP            7
#define BUTTON_RIGTH         8
#define BUTTON_R_SEL         9
#define PWR_KEY_PRESSED     10
#define PWR_KEY_RELEASED    11

/* Converts a time in seconds to a time in ticks. */
#define pdSec_TO_TICKS( xTimeInSec ) ( ( ( TickType_t ) ( xTimeInSec ) * configTICK_RATE_HZ ) )

#define GPIO_HWTIM_DEBUG_PIN 2

#define ESP_INTR_FLAG_DEFAULT       0
#define GPIO_RADIO_IRQ              22

// Check the MAKEFILE declaration of this definition
#define LCD_BLK_ON gpio_set_level(ILI9341_BCKL, 1)
#define LCD_BLK_OFF gpio_set_level(ILI9341_BCKL, 0)


// UI Task commands

#define UI_TASK_COMMAND_UPDATE_HEDADER      101
#define UI_TASK_COMMAND_READBATANDUPDATE    102
#define UI_TASK_COMMAND_UPDATE_COUNTER      103
#define UI_TASK_COMMAND_HIDE_COUNTER        104
#define UI_TASK_PG_START_NORADIOMODULE      105
#define UI_TASK_PG_START_NOIFMODULE         106

#define MAX_TASK_NUM 20                         // Max number of per tasks info that it can store
#define MAX_BLOCK_NUM 20                        // Max number of per block info that it can store

static size_t s_prepopulated_num = 0;


static const char* TAG = "MAIN";

static xQueueHandle gpio_evt_queue = NULL;
static xQueueHandle ui_evt_queue = NULL;
static xQueueHandle util_evt_queue = NULL;
esp_timer_handle_t hw_timer;
esp_timer_handle_t hw_timer_oneshut;
esp_timer_handle_t hw_timer_calibrator;
uint64_t hw_timer_elapsed_ms;
uint16_t hw_timer_ms;
volatile uint8_t hw_timer_sec;
volatile uint8_t hw_timer_min;
volatile bool isHwTimerRunning;
volatile bool isHwCalibratorRunning;
volatile bool isHwCalibratorMeasurementAvaible;
uint32_t hw_calibrator_elapsed_us;
uint8_t battery_percent;
volatile bool isBatteryCharging;
volatile bool isBatteryCharged;
volatile bool isSyncPacketPreloaded;
volatile bool syncStart_begin;
volatile bool hidembox;
volatile bool if_irq_pending;
volatile bool is_lcd_backlight_on;
uint8_t syncStart_node_index;
static uint16_t fVoltageMatrix[22][2] = {
                                        {4200, 100},
                                        {4150, 95},
                                        {4110, 90},
                                        {4080, 85},
                                        {4020, 80},
                                        {3980, 75},
                                        {3950, 70},
                                        {3910, 65},
                                        {3870, 60},
                                        {3850, 55},
                                        {3840, 50},
                                        {3820, 45},
                                        {3800, 40},
                                        {3790, 35},
                                        {3770, 30},
                                        {3750, 25},
                                        {3730, 20},
                                        {3710, 15},
                                        {3690, 10},
                                        {3610, 5},
                                        {3270, 0},
                                        {0, 0}
};

static void IRAM_ATTR gpio_isr_handler(void* arg);
static void IRAM_ATTR hw_timer_calibrator_cb(void *args);
void updateHomePageCache();
void esp_setupGpioInterrupts(bool radio_irq_enable);
void start_hw_timer();
void stop_hw_timer();
uint8_t battery_measure();
void _startSync(uint8_t node_index );
uint8_t decode_battery_info(uint8_t charge_state);
void setLCDBackLigthLevel(uint8_t level);
void fadeOutBackLigth();
void fadeInBackLigth(uint8_t target_brigtness);

static void hw_timer_callback(void* arg);
void powerOffConfirm_callback(uint8_t answer);
void deleteAllNodeConfirm_callback(uint8_t);

static void IRAM_ATTR lv_tick_task(void);
static void gpio_task(void* arg);
static void ui_task(void* args);
static void utilities_task(void * args);
static void update_NodeStatus_task(void *args);
TaskHandle_t UNST_handle;
// static void update_BatteryStatus_task(void *args);
// static void node_signal_strength_measure_task(void *args);
// static void scan_frequency_map_task(void *args);
static void IRAM_ATTR lv_tick_task(void);

// GPIO IRQ handler, this is not actually a handler, just a queue updater
static void IRAM_ATTR gpio_isr_handler(void* arg)


{
    uint32_t gpio_num = (uint32_t) arg;
    xQueueSendFromISR(gpio_evt_queue, &gpio_num, NULL);
}
// GPIO IRQ handler StateMachine
static void gpio_task(void *arg)
{
    uint32_t io_num;
    for (;;)
    {
        if (xQueueReceive(gpio_evt_queue, &io_num, portMAX_DELAY))
        {
            printf("GPIO[%d] intr, val: %d\n", io_num, gpio_get_level(io_num));
            switch (io_num)
            {
            case GPIO_RADIO_IRQ:
                radio_DataSentCallback();
                break;
            case IF_IRQ_GPIO:
                if_irq_pending = 1;
                break;
            default:
            {
                break;
            }
            }
        }
    }
}

// GPIO Config
void esp_setupGpioInterruptsTask()
{
    //create a queue to handle gpio event from isr
    gpio_evt_queue = xQueueCreate(10, sizeof(uint32_t));
    //start gpio task
    xTaskCreate(gpio_task, "gpio_task", 2048, NULL, 10, NULL);
    //install gpio isr service
    gpio_install_isr_service(ESP_INTR_FLAG_DEFAULT);
    //  hook isr handler for specific gpio pin
    //  switches are mapped here for their functions
    
}

static void ui_task(void *args)
{
    uint8_t queue_data;
    // Init UI pages
    ui_pages_t ui_pages;
    ui_pages.current_page = UI_PAGE_HOME;
    ui_pages.pages = malloc(sizeof(ui_pages_t) * UI_PAGES);

    ui_pages.pages[0].page_id = UI_PAGE_HOME;
    ui_pages.pages[0].parent_page_id = UI_PAGE_HOME;

    ui_pages.pages[1].page_id = UI_PAGE_ACTION_MENU;
    ui_pages.pages[1].parent_page_id = UI_PAGE_HOME;
    
    ui_pages.pages[2].page_id = UI_PAGE_SETTINGS;
    ui_pages.pages[2].parent_page_id = UI_PAGE_HOME;

    ui_pages.pages[3].page_id = UI_PAGE_PAIRNODE;
    ui_pages.pages[3].parent_page_id = UI_PAGE_HOME;

    ui_pages.pages[4].page_id = UI_PAGE_PAIRNODE_SUCCES;
    ui_pages.pages[4].parent_page_id = UI_PAGE_HOME;
    
    ui_pages.pages[5].page_id = UI_PAGE_STARTSTOP_MENU;
    ui_pages.pages[5].parent_page_id = UI_PAGE_HOME;

    ui_pages.pages[8].page_id = UI_PAGE_CALIBRATION;
    ui_pages.pages[8].parent_page_id = UI_PAGE_HOME;

    ui_pages.pages[9].page_id = UI_PAGE_MBOX;
    ui_pages.pages[9].parent_page_id = UI_PAGE_HOME;

    long pwr_btn_press_timestamp = 0; 
    long pwr_btn_release_timestamp = 0;  

    for(;;){
        if(xQueueReceive(ui_evt_queue, &queue_data, portMAX_DELAY)){
            printf("\nUI task ent handler loop queue data : %d\n", queue_data);
            // First check the backligth status, if no backligh, we turn it on, and skip btn action
            if(is_lcd_backlight_on == false){
                fadeInBackLigth(0xFF);
                ws2812_clearLed();
                pwr_btn_press_timestamp = xTaskGetTickCount();
            }
            // BTN values always under value 100, values more than 100 means another ui operation like updates, or page launches
            if(queue_data < 100 && is_lcd_backlight_on == false){
                // btn release have to change backlight is on flag
                if(queue_data != PWR_KEY_PRESSED){
                    is_lcd_backlight_on = true;
                }
                continue;
            }
            switch (queue_data)
            {
                case BUTTON_ENTER:
                    switch(ui_pages.current_page)
                    {
                        case UI_PAGE_HOME:
                            // Redirect the event to littlevGL, this will draw the action menu too
                            lv_inputdev_buttonPressed(LV_KEY_ENTER, 1);
                            ui_pages.current_page = UI_PAGE_ACTION_MENU;
                            break;
                        case UI_PAGE_ACTION_MENU:
                            lv_inputdev_buttonPressed(LV_KEY_ENTER, 1);
                            break;
                        case UI_PAGE_SETTINGS:
                            // What settings can be here...
                            break;
                        case UI_PAGE_PAIRNODE:
                            ui_drawPage_PairNode(UI_PAIRN_STATE_ARMED);
                            radio_pairNode();
                            while(radio_isBusy());
                            if(nodebank_isLastPairSuccess()){
                            // if(1){
                                ui_pages.current_page = UI_PAGE_PAIRNODE_SUCCES;
                                ui_drawPage_PairNode(UI_PAIRN_STATE_PAIRSUCCESS);
                            } else {
                                 ui_drawPage_PairNode(UI_PAIRN_STATE_PAIRFAILED);
                            }
                            break;
                        case UI_PAGE_MBOX:
                        case UI_PAGE_PAIRNODE_SUCCES:
                            lv_inputdev_buttonPressed(LV_KEY_ENTER, 1);
                            break;
                        case UI_PAGE_STARTSTOP_MENU:
                            // STOP Button
                            if(isHwTimerRunning){
                                vTaskSuspend(UNST_handle);
                                radio_sendBroadCastPackage(RADIO_BROADCAST_CMD_START);
                                vTaskResume(UNST_handle);
                                ui_toggleActionMenuBtnState(LV_SYMBOL_STOP);
                                // This is create a bug, when the timer is resumed
                                stop_hw_timer();
                                ui_setCounterVisibility(false);
                                vTaskDelay(20);
                                ui_toggleActionMenuBtnState(LV_SYMBOL_STOP);
                            }
                            break;
                        default:
                            break;
                    }
                    break;
                case BUTTON_DOWN:
                    switch(ui_pages.current_page){
                        case UI_PAGE_ACTION_MENU:
                        case UI_PAGE_HOME:
                        case UI_PAGE_PAIRNODE_SUCCES:
                            lv_inputdev_buttonPressed(LV_KEY_DOWN, 1);
                            break;
                        case UI_PAGE_STARTSTOP_MENU:
                            // Stop Button
                            // Pause Node Update Task for a little bit
                            vTaskSuspend(UNST_handle);
                            radio_sendBroadCastPackage(RADIO_BROADCAST_CMD_STOP);
                            vTaskResume(UNST_handle);
                            ui_toggleStopBtnState_StartStopMenu();
                            vTaskDelay(20);
                            ui_toggleStopBtnState_StartStopMenu();
                        default:
                            break;
                    }
                    break;
                case BUTTON_UP:
                    switch(ui_pages.current_page){
                        case UI_PAGE_ACTION_MENU:
                        case UI_PAGE_HOME:
                        case UI_PAGE_PAIRNODE_SUCCES:
                            lv_inputdev_buttonPressed(LV_KEY_UP, 1);
                            break;
                        case UI_PAGE_STARTSTOP_MENU:
                            // Play1 Button
                            if(!isHwTimerRunning){
                                vTaskSuspend(UNST_handle);
                                radio_sendBroadCastPackage(RADIO_BROADCAST_CMD_START);
                                vTaskResume(UNST_handle);
                                ui_toggleActionMenuBtnState(LV_SYMBOL_PLAY);
                                // This is create a bug, when the timer is resumed
                                ui_updateCounter(0,0);
                                ui_setCounterVisibility(true);
                                vTaskDelay(20);
                                ui_toggleActionMenuBtnState(LV_SYMBOL_PLAY);
                            }
                            break;
                        default:
                            break;
                    }
                    break;
                case BUTTON_LEFT:
                    switch(ui_pages.current_page){
                        case UI_PAGE_HOME:
                            lv_inputdev_buttonPressed(LV_KEY_PREV, 1);
                            break;
                        case UI_PAGE_PAIRNODE_SUCCES:
                        case UI_PAGE_ACTION_MENU:
                            lv_inputdev_buttonPressed(LV_KEY_LEFT, 1);
                            break;
                        case UI_PAGE_MBOX:
                            lv_inputdev_buttonPressed(LV_KEY_DOWN, 1);
                            break;
                        default:
                            break;
                    }
                    break;
                case BUTTON_RIGTH:
                    switch(ui_pages.current_page){
                        case UI_PAGE_HOME:
                            lv_inputdev_buttonPressed(LV_KEY_NEXT, 1);
                            break;
                        case UI_PAGE_PAIRNODE_SUCCES:
                        case UI_PAGE_ACTION_MENU:
                            lv_inputdev_buttonPressed(LV_KEY_RIGHT, 1);
                            break;
                        case UI_PAGE_MBOX:
                            lv_inputdev_buttonPressed(LV_KEY_UP, 1);
                            break;
                        default:
                            break;
                    }
                    break;
                case BUTTON_BACK:
                    switch(ui_pages.current_page){
                        case UI_PAGE_ACTION_MENU:
                            ui_pages.current_page = ui_pages.pages[UI_PAGE_ACTION_MENU].parent_page_id;
                            ui_hidePage_ActionMenu();
                            break;
                        case UI_PAGE_PAIRNODE:
                            ui_drawHomePage();
                            uint8_t queue_data = PG_SWITCHED_TO_HOMEPAGE;
                            xQueueSend( ui_evt_queue, &queue_data, NULL);
                            break;
                        case UI_PAGE_HOME:
                            ui_pages.current_page = UI_PAGE_STARTSTOP_MENU;
                            ui_drawStartStopMenu();
                            break;
                        case UI_PAGE_STARTSTOP_MENU:
                            ui_pages.current_page = ui_pages.pages[UI_PAGE_STARTSTOP_MENU].parent_page_id;
                            ui_hidePage_StartStopMenu();
                            break;
                        default:
                            break;
                    }
                    break;
                case BUTTON_L_SEL:
                    switch(ui_pages.current_page){
                        case UI_PAGE_STARTSTOP_MENU:
                            vTaskSuspend( UNST_handle );
                            ui_pages.current_page = UI_PAGE_PAIRNODE;
                            ui_drawPage_PairNode(UI_PAIRN_STATE_INIT);
                            break;
                        case UI_PAGE_PAIRNODE_SUCCES:
                            lv_inputdev_hwbuttonPressed(LV_EVENT_CANCEL, 1);
                            break;
                        default:
                            break;
                    }
                    break;
                case BUTTON_R_SEL:
                    switch(ui_pages.current_page){
                        case UI_PAGE_STARTSTOP_MENU:
                            // nodebank_deletePairedNodes();
                            ui_drawConfirmMbox("Do you realy want to delete all paired nodes?", deleteAllNodeConfirm_callback);
                            break;
                        case UI_PAGE_HOME:
                            lv_inputdev_buttonPressed(LV_KEY_HOME, 1);
                            break;
                        case UI_PAGE_PAIRNODE_SUCCES:
                            lv_inputdev_hwbuttonPressed(LV_EVENT_APPLY, 1);
                            break;
                        default:
                            break;
                    }
                    break;
                 case BUTTON_ALT:
                    switch(ui_pages.current_page){
                        case UI_PAGE_STARTSTOP_MENU:
                            // There is no action yet.
                            break;
                        case UI_PAGE_HOME:
                            lv_inputdev_buttonPressed(LV_KEY_END, 1);
                            break;
                        default:
                            break;
                    }
                    break;
                case PWR_KEY_PRESSED:
                    // PWR btn action allowed only in homepage
                    if(ui_pages.current_page == UI_PAGE_HOME){
                        pwr_btn_press_timestamp = xTaskGetTickCount(); 
                    }
                    break;
                case PWR_KEY_RELEASED:
                    // PWR btn action allowed only in homepage
                    if(ui_pages.current_page == UI_PAGE_HOME){
                        pwr_btn_release_timestamp = xTaskGetTickCount();
                        if(pwr_btn_release_timestamp - pwr_btn_press_timestamp >= PWR_BTN_LONG_PRESS_DURATION_TICK){
                            // Show PWR OFF alert dialog
                            ui_drawConfirmMbox("Do you really want to turn off?", powerOffConfirm_callback);
                        } else if(is_lcd_backlight_on){
                            fadeOutBackLigth();
                            ws2812_setColor(COLOR_GREEN);
                            is_lcd_backlight_on = false;
                        } else {
                            // Already turned on, just for logic
                            is_lcd_backlight_on = true;
                        }
                    }
                    break;
                // Requests from UI and another not GUI related functions
                case CMD_DEL_NODES_REQ:
                    nodebank_deletePairedNodes();
                    break;
                case UI_TASK_COMMAND_UPDATE_COUNTER:
                    ui_updateCounter(hw_timer_min, hw_timer_sec);
                    break;
                case UI_TASK_COMMAND_HIDE_COUNTER:
                    ui_setCounterVisibility(false);
                    break;
                case UI_TASK_PG_START_NORADIOMODULE:
                    ui_drawWarningMbox("No radio module found!");
                    break;
                case UI_TASK_PG_START_NOIFMODULE:
                    ui_drawWarningMbox("No if module found!");
                    break;
                case PG_SWITCHED_TO_HOMEPAGE:
                    ui_pages.current_page = UI_PAGE_HOME;
                    vTaskResume( UNST_handle );
                    break;
                case PG_SWITCHED_TO_PAIRNODE:
                    ui_pages.current_page = UI_PAGE_PAIRNODE;
                    break;
                case PG_SWITCHED_TO_MBOX:
                    ui_pages.current_page = UI_PAGE_MBOX;
                    break;
                default:
                    break;
            }
        }
    }

}
// This task is fire when user sitting on radio_settings page, ping the nodes, and report signal strengts.
// If all node are pinged, update the cache  and send a request for UI_task to refress the signals
// static void node_signal_strength_measure_task(void *args){
//     uint8_t node_count = nodebank_getNodeCount();
//     uint8_t *node_signal_strength;
//     if(node_count > 3){
//         node_count = 3;
//     }
//     node_signal_strength = malloc(node_count * sizeof(uint8_t));

//     // Turn nodes to range test mode a.k.a. ping command

//     uint8_t i;
//     for(i = 0; i < node_count; i++){
//         radio_activateRangeTestMode(i);
//         while(radio_isBusy());
//         if(radio_isLastTransmissionSucces()){
//             // Do something if the node is unreachable
//         }
//     }

//     // Set radio parameters for best range
//     nrf24_disableFeaures();
//     nrf24_setPayloadLength(0, 5);

//     for(;;){
//         uint8_t i;
//         for(i = 0; i < node_count; i++){
//             radio_pingNode(i);
//             while(radio_isBusy());
//             if(radio_isLastTransmissionSucces()){
//                 node_signal_strength[i] = radio_getLastTransmissionSignalQuality();
//             } else {
//                 node_signal_strength[i] = 0;
//             }
//         }
//         ux_radio_settings_updateCache(node_signal_strength);
//         uint8_t ui_cmd = UI_TASK_COMMAND_UPDATE;
//         xQueueSend(ui_evt_queue, &ui_cmd, 0);

//         vTaskDelay( pdMS_TO_TICKS(1000) );

//     }
// }
// This task is for scan all radio channels and measure activitiy on the current channel
// static void scan_frequency_map_task(void *args){
//     for(;;){
//         uint8_t i;
//         for(i = 0; i < RADIO_AVAIABLE_CHANNELS; i++){
//             uint8_t measure_rounds = 10;
//             uint8_t channel_quality = 0;
//             color_t channel_color;
//             while(measure_rounds){
//                 radio_start_listenOnChannel(i);
//                 vTaskDelay( pdMS_TO_TICKS(500) );
//                 uint8_t channel_noise = radio_stop_listenOnChannel();
//                 if(channel_noise){
//                     channel_quality++;
//                 }
//                 measure_rounds--;
//             }
//             if(channel_quality > 5){
//                 channel_color = TFT_RED;
//             } else if(channel_quality > 3){
//                 channel_color = TFT_YELLOW;
//             } else {
//                 channel_color = TFT_GREEN;
//             }
//             ux_freq_map_updateCache( i, channel_color);
//             uint8_t ui_cmd = UI_TASK_COMMAND_UPDATE;
//             xQueueSend(ui_evt_queue, &ui_cmd, 0);
//         }
//     }
// }

static void update_NodeStatus_task(void *args){
    for(;;){
        if(nodebank_getNodeCount() > 0){
            uint8_t i;
            uint8_t node_count = nodebank_getNodeCount();
            for(i = 0; i < node_count; i++){
                while(radio_isBusy());
                ESP_LOGD(TAG, "Sending status request...");
                radio_sendStatusRequest(i);
                while(radio_isBusy());
                if(radio_isLastTransmissionSucces()){
                    if(radio_hasAckPayload()){
                        struct payload *p = radio_getLastResponse();
                        // Check the sync request
                        if(p->data1 == NODE_STATUS_SYNC_REQ){
                            _startSync(i);
                            ui_drawWarningMbox("Node sync in progress...");
                            break;
                        }
                        nodebank_setActiveNodeStatus(p->data1);
                        if(p->data1 == NODE_STATUS_FAIL){
                            nodebank_setActiveNodeErrorCode( p->data2 );
                            ESP_LOGD(TAG, "Status transaction success, Command: %d, Status %d, Error Code: %d",p->command, p->data1, p->data2);
                        } else {
                            uint16_t battery_voltage = ((uint16_t)p->data2 << 8) | (p->data3);
                            nodebank_setActiveNodeBatteryVoltage(battery_voltage);
                            ESP_LOGD(TAG, "Status transaction success, Command: %d, Status %d, BatteryV: %d",p->command, p->data1, battery_voltage);
                            uint8_t perc = 0;
                            uint8_t j;
                            for(j=0; fVoltageMatrix[j][0] > 0; j++) {
                              if(battery_voltage >= fVoltageMatrix[j][0]) {
                                perc = fVoltageMatrix[j][1];
                                break;
                                }
                            }
                            nodebank_setActiveNodeBatteryPercent(perc);
                            nodebank_setActiveNodeSignal(radio_getLastTransmissionSignalQuality());
                        }
                    } else {
                        // No payload received from node... maybe the node was too slow
                        // The next status request will do it
                        
                    }
                } else {
                        // No response from node
                        nodebank_setActiveNodeStatus(NODE_STATUS_DISCONNECTED);
                        nodebank_setActiveNodeSignal(0);
                        ESP_LOGD(TAG, "No response for status request NODE: %d",nodebank_getNodeSubAddresbyIndex(i));
                }
                ui_updateNextNode();
            }
            ui_updateNextNodeFinished();
            vTaskDelay( pdMS_TO_TICKS(3000) );
        } else {
            vTaskDelay( pdMS_TO_TICKS(2000) );
        }
    }
}

#define BATTERY_UPDATE_PERIOD 20 // Define how often read the battery status, base is 1sec 

static void utilities_task(void * args){
    uint8_t last_charge_state = 0;
    uint8_t queue_data;
    uint8_t task_counter = BATTERY_UPDATE_PERIOD;  // set this to the value which is trigger the battery status update
    // vTaskDelay( pdMS_TO_TICKS (1000));
    for(;;){
        //Handle QUEUE
        if(xQueueReceive(util_evt_queue, &queue_data, 0)){
            switch (queue_data)
            {
            case BATTERY_CHARGING:
                ui_UpdateBatteryStatus(BATTERY_CHARGING);
                ESP_LOGD("Util Task","Charger connected");
                break;
            case BATTERY_CHR_DISCONNECTED:
                ui_UpdateBatteryStatus(BATTERY_CHR_DISCONNECTED);
                ESP_LOGD("Util Task","Charger disconnected");
                break;
            default:
                ESP_LOGD("Util Task", "Queue data %d",queue_data);
                // This is a charge state
                if (queue_data == BATTERY_CHRG_STATE_CHARGING){ 
                    ESP_LOGD("Util Task","Battery charging");
                }
                else if (queue_data == BATTERY_CHRG_STATE_CHARGE_DONE){
                    ESP_LOGD("Util Task","Battery charged");
                    ui_UpdateBatteryStatus(decode_battery_info(queue_data));
                    // calibrate voltage readings
                }
                else if (queue_data == BATTERY_CHRG_STATE_IDLE){
                    ESP_LOGD("Util Task","No Battery");
                } else {
                    ESP_LOGD("Util Task","Unkown %d", queue_data);
                }
                break;
            }
            queue_data = 0;
        }
        // Try to access SPI Bus
        uint8_t timeout_counter = 0;
        while( (radio_isBusy() || if_isBusy()) && timeout_counter <= 5 ){
            timeout_counter++;
            vTaskDelay( pdMS_TO_TICKS(1) );
        }
        if(timeout_counter <= 5){
            // Ping if to reset AVR WDT
            if_ping();
            // ESP_LOGD("Util Task", "FW PING");
            if(task_counter >= BATTERY_UPDATE_PERIOD ){
                // Read battery info from IF
                uint8_t buffer[3];
                if_requestBatteryInfo();
                vTaskDelay( pdMS_TO_TICKS(150) );
                if_readBatteryInfo( buffer );
                uint16_t battery_voltage = buffer[1];
                battery_voltage <<= 8;
                battery_voltage |= buffer[2];
                uint8_t charge_state = buffer[0];
                // Update Battery status, not the percent value
                if(last_charge_state != charge_state){
                    last_charge_state = charge_state;
                    ESP_LOGD("Util Task","Battery status updated %d", last_charge_state);
                    if(last_charge_state == BATTERY_CHRG_STATE_CHARGE_DONE){
                        ui_UpdateBatteryStatus(decode_battery_info(last_charge_state));
                    }
                }
                uint8_t i;
                for(i = 0; fVoltageMatrix[i][0] > 0; i++) {
                    if(battery_voltage >= fVoltageMatrix[i][0]) {
                      battery_percent = fVoltageMatrix[i][1];
                      break;
                    }
                }
                // No battery status affected to the battery icon, so we dont want to overide it, if it is active
                // If battery charged then we want to prevent to override it with percent value
                if( charge_state != BATTERY_CHRG_STATE_IDLE && last_charge_state != BATTERY_CHRG_STATE_CHARGE_DONE){
                    ui_UpdateBatteryStatus(battery_percent);
                    ESP_LOGD("Util task","Battery percent updated %d", battery_percent);
                }
                task_counter = 0;
            }

                // If the battery is charging, we read its voltage less often
                if(last_charge_state == BATTERY_CHRG_STATE_CHARGING){
                    task_counter += 1;
                } else {
                    task_counter += 2;
                }
                vTaskDelay( pdMS_TO_TICKS(2000) );
            } else {
                // We got timeout, We will try it later
                vTaskDelay( pdMS_TO_TICKS( 1000 ) );
                ESP_LOGD("UTIL Task", "Timeout...");
            }
    }
}

void app_main(){

    ws2812_control_init();
    ws2812_setColor(COLOR_GREEN);

    // LCD Backligth Controll
    ledc_timer_config_t ledc_timer = {
        .duty_resolution = LEDC_TIMER_8_BIT, // resolution of PWM duty
        .freq_hz = 5000,                      // frequency of PWM signal
        .speed_mode = LEDC_LOW_SPEED_MODE,           // timer mode
        .timer_num = LEDC_TIMER_1,            // timer index
        .clk_cfg = LEDC_AUTO_CLK,              // Auto select the source clock
    };
    ledc_timer_config(&ledc_timer);

    ledc_channel_config_t ledc_channel[1] = {
        {
            .channel    = LEDC_CHANNEL_2,
            .duty       = 0,
            .gpio_num   = ILI9341_BCKL,
            .speed_mode = LEDC_LOW_SPEED_MODE,
            .hpoint     = 0,
            .timer_sel  = LEDC_TIMER_1
        }
    };
    ledc_channel_config(&ledc_channel[0]);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, 0xFF);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2);
    ledc_fade_func_install(0);

	nodebank_init(NULL);
    battery_percent = 0;
    isBatteryCharged = false;
    isBatteryCharging = false;
    isSyncPacketPreloaded = false;
    is_lcd_backlight_on = true;
    syncStart_begin = false;
    hidembox = false;
    syncStart_node_index = 0;
    // Setting up HW timers
    const esp_timer_create_args_t hw_timer_args = {
            .callback = &hw_timer_callback,
            /* argument specified here will be passed to timer callback function */
            // .arg = (void*) periodic_timer,
            .name = "periodic"
    };

    const esp_timer_create_args_t hw_timer_args_one_shut = {
            .callback = &start_hw_timer,
            /* argument specified here will be passed to timer callback function */
            // .arg = (void*) periodic_timer,
            .name = "one-shut"
    };

    const esp_timer_create_args_t hw_timer_args_calibrator = {
            .callback = &hw_timer_calibrator_cb,
            /* argument specified here will be passed to timer callback function */
            // .arg = (void*) periodic_timer,
            .name = "calibrator"
    };
    // This timer count the elpased time from the start of the animation
    ESP_ERROR_CHECK(esp_timer_create(&hw_timer_args, &hw_timer));
    // This timer is for delaying the  elapsed time counter due to copensate the lag of the radio modules
    ESP_ERROR_CHECK(esp_timer_create(&hw_timer_args_one_shut, &hw_timer_oneshut));
    // This is a node frequency calibrator timer
    ESP_ERROR_CHECK(esp_timer_create(&hw_timer_args_calibrator, &hw_timer_calibrator));

    esp_timer_stop(hw_timer);
    esp_timer_stop(hw_timer_oneshut);
    esp_timer_stop(hw_timer_calibrator);

    // BUG: The first anim command from reset is delayed with 30uS
    // Dummy start of timers can help a little bit but still delayed
    esp_timer_start_once(hw_timer_oneshut, 500);
    ets_delay_us(2000);

    esp_timer_stop(hw_timer);
    esp_timer_stop(hw_timer_oneshut);

    hw_timer_elapsed_ms = 0;
    hw_timer_sec = 0;
    hw_timer_min = 0;
    isHwTimerRunning = false;

	// UI
	ui_evt_queue = xQueueCreate(20, sizeof(uint8_t));
    ui_Init(&ui_evt_queue);
	esp_register_freertos_tick_hook(lv_tick_task);
	ui_drawHomePage();
    xTaskCreate(ui_task, "ui_task", 2048, NULL, 3, NULL);
    
    esp_setupGpioInterruptsTask();

    // DBG
    gpio_set_level(GPIO_HWTIM_DEBUG_PIN, 0);
    ets_delay_us(1 * 1000 * 1000); // 1s wait
    if(!if_init()){
        uint8_t ui_task_cmd = UI_TASK_PG_START_NOIFMODULE;
        // Notify the UI task about the IF module
        xQueueSend(ui_evt_queue, &ui_task_cmd, NULL);
    } else {
        // IF module init done, setup IRQ
        gpio_config_t io_conf;
        io_conf.intr_type = GPIO_PIN_INTR_POSEDGE;
        io_conf.pin_bit_mask = ( (uint64_t)1 << IF_IRQ_GPIO );
        io_conf.mode = GPIO_MODE_INPUT;
        io_conf.pull_up_en = 0;
        gpio_config(&io_conf);
        gpio_isr_handler_add(IF_IRQ_GPIO, gpio_isr_handler, (void*) IF_IRQ_GPIO);
        // Create a task for reading battery voltage and external power sources
        xTaskCreate(utilities_task, "Util_task", 2048, NULL, 3, NULL);
        util_evt_queue = xQueueCreate(8, sizeof(uint8_t));
    }

    gpio_set_level(GPIO_HWTIM_DEBUG_PIN, 1);
    radio_init();
    // Check radio module
    if( !radio_isAvailable() ){
        uint8_t ui_task_cmd = UI_TASK_PG_START_NORADIOMODULE;
        // Notify the UI task about the radio module
        xQueueSend(ui_evt_queue, &ui_task_cmd, NULL);
    } else {
        gpio_config_t io_conf;
        io_conf.intr_type = GPIO_PIN_INTR_NEGEDGE;
        io_conf.pin_bit_mask = ( (uint64_t)1 << GPIO_RADIO_IRQ );
        io_conf.mode = GPIO_MODE_INPUT;
        io_conf.pull_up_en = 1;
        gpio_config(&io_conf);
        gpio_isr_handler_add(GPIO_RADIO_IRQ, gpio_isr_handler, (void*) GPIO_RADIO_IRQ);
        xTaskCreate(update_NodeStatus_task, "NSupdater", 2048, NULL, 2, &UNST_handle);
    }
    // Heap usage Task
    // xTaskCreate(&heap_usage_task, "heap_usage_task", 2048, NULL, 5, NULL);
    ws2812_clearLed();
    ESP_LOGD("MAIN","Init finished, entering mail loop");
	while(1) {
		vTaskDelay(1);
        // SyncStart need to be moved out from ui_task
        if(syncStart_begin && isHwTimerRunning){
            // Pause Node Update Task for a little bit
            gpio_set_level(GPIO_HWTIM_DEBUG_PIN, 0);
            nodebank_selectActiveNode(syncStart_node_index);
            uint8_t last_sec = hw_timer_sec;
            // wait until the next sec  incrementation
            // In this way we had enough time to do thinks
            while(last_sec == hw_timer_sec);
            gpio_set_level(GPIO_HWTIM_DEBUG_PIN, 1);
            // Preload the current time and this is the current plus 1 sec because the CE pin will be activated rigth on the next second
            radio_preloadSyncPacket(hw_timer_min, (hw_timer_sec + 1) );
            isSyncPacketPreloaded = true;
            // Wait until the HWtimer callback activate the transmission
            // This waiting take almost a second
            while(isSyncPacketPreloaded);
            // The transmission take another 245uS from rising the CE pin of the radio to IRQ pin pulldown on the node
            ets_delay_us(15);
            gpio_set_level(NRF24_CE, 0);
            while(radio_isBusy());
            syncStart_begin = false;
            hidembox = true;
            vTaskResume(UNST_handle);
        }
        if(isHwCalibratorMeasurementAvaible){
            isHwCalibratorMeasurementAvaible = false;
            ui_updateCalibrationMbox( (uint16_t) hw_calibrator_elapsed_us );
            hw_calibrator_elapsed_us = 0;
        }
        if(hidembox){
            if(ui_hideWarningMbox()){
                hidembox = false;
            }
        }
        if(if_irq_pending){
            if( ! (radio_isBusy() || if_isBusy()) ){
                uint8_t irq_source;
                if_irq_pending = false;
                if_getIRQ( &irq_source);
                switch(irq_source){
                    case IRQ_SOURCE_KBM:{
                        uint8_t keys[3];
                        if_getKeyboardMatrixData(keys);
                        xQueueSend(ui_evt_queue, &keys[0], NULL);
                        break;
                    }
                    case IRQ_SOURCE_BATT_STATE:{
                        // We read the charge state here only
                        uint8_t buffer[3];
                        if_getBatteryInfo(buffer);
                        uint8_t charge_state = buffer[0];
                        xQueueSend(util_evt_queue, &charge_state, NULL);
                        break;
                    }
                    case IRQ_SOURCE_VIN_STATE:{
                        uint16_t vin_voltage = if_getVinVoltage();
                        if(vin_voltage >= VIN_VOLTAGE_TRESHOLD){
                            if_enableCharging();
                            // ui_UpdateBatteryStatus(BATTERY_CHARGING);
                            uint8_t charge_state = BATTERY_CHARGING;
                            xQueueSend(util_evt_queue, &charge_state, NULL);
                        } else {
                            if_disableCharging();
                            // ui_UpdateBatteryStatus(BATTERY_CHR_DISCONNECTED);
                            uint8_t charge_state = BATTERY_CHR_DISCONNECTED;
                            xQueueSend(util_evt_queue, &charge_state, NULL);
                        }
                        // Wait a litle bit for the charge controller
                        ets_delay_us(10 * 1000);
                        // Update battery info
                        uint8_t buffer[3];
                        // Most probably, we get an IRQ from PWR_MAN too
                        if(if_irq_pending){
                            if_getIRQ( &irq_source );
                            if_irq_pending = false;
                            if_getBatteryInfo(buffer);
                            uint8_t charge_state = buffer[0];
                            ui_UpdateBatteryStatus(decode_battery_info(charge_state));
                        }
                        break;
                    }
                    case IRQ_SOURCE_PWR_KEY:{
                        uint8_t key_state;
                        if_getPwrKeyState(&key_state);
                        if( key_state){
                            key_state = PWR_KEY_PRESSED;
                        } else {
                            key_state = PWR_KEY_RELEASED;    
                        }
                        xQueueSend(ui_evt_queue, &key_state, NULL);
                        break;
                    }
                }
            }
        }
		lv_task_handler();
	}
}

static void IRAM_ATTR lv_tick_task(void)
{
	lv_tick_inc(portTICK_RATE_MS);
}

void IRAM_ATTR start_hw_timer(){
    isHwTimerRunning = true;
    esp_timer_start_periodic(hw_timer, 1000);
    

}

void IRAM_ATTR start_hw_timer_one_shut(){
    esp_timer_start_once(hw_timer_oneshut, 282);
}

void stop_hw_timer(){
    esp_timer_stop(hw_timer);
    hw_timer_elapsed_ms = 0;
    hw_timer_min = 0;
    hw_timer_sec = 0;
    hw_timer_ms = 0;
    isHwTimerRunning = false;
    uint8_t ui_task_cmd = UI_TASK_COMMAND_HIDE_COUNTER;
    xQueueSend(ui_evt_queue, &ui_task_cmd, NULL);
}

static void IRAM_ATTR hw_timer_callback(void* arg)
{
    hw_timer_elapsed_ms++;
    hw_timer_ms++;
    if(hw_timer_ms > 999){
        // If we are starting the syncronisation, we will start the node on the begining of the next second
        if(isSyncPacketPreloaded)
        {
            gpio_set_level(NRF24_CE, 1);
            isSyncPacketPreloaded = false;
        }
        hw_timer_sec++;
        hw_timer_ms = 0;
        uint8_t ui_task_cmd = UI_TASK_COMMAND_UPDATE_COUNTER;
        // Notify the UI task to update the counter
        xQueueSend(ui_evt_queue, &ui_task_cmd, NULL);
    }
    if(hw_timer_sec > 59){
        hw_timer_sec = 0;
        hw_timer_min++;
    }
}

static void IRAM_ATTR hw_timer_calibrator_cb(void *args){
    hw_calibrator_elapsed_us++;
}

// This is called from the UI and can be called from the NSupdate task at external sync req.
// External sync req. can be a sync reqest by a node
void _startSync(uint8_t node_index ){
    syncStart_node_index = node_index;
    syncStart_begin = true;
}

uint8_t decode_battery_info(uint8_t charge_state)
{
    if (charge_state == BATTERY_CHRG_STATE_CHARGING){
        return BATTERY_CHARGING;
    }
    else if (charge_state == BATTERY_CHRG_STATE_CHARGE_DONE){
        return BATTERY_CHARGED;
    }
    else if (charge_state == BATTERY_CHRG_STATE_IDLE){
        return BATTERY_CHR_DISCONNECTED;
    } else {
        return 0;
    }
}

void powerOffConfirm_callback(uint8_t answer){
    if (answer){
        ui_hideConfirmMbox();
        if_disableVin();
    }
}

void deleteAllNodeConfirm_callback(uint8_t answer){
    if (answer){
        ui_hideConfirmMbox();
        nodebank_deletePairedNodes();
        ui_drawHomePage();
        uint8_t queue_data = PG_SWITCHED_TO_HOMEPAGE;
        xQueueSend(ui_evt_queue, &queue_data, NULL);
    } else
    {
        ui_hideConfirmMbox();
    }
    
}

void setLCDBackLigthLevel(uint8_t level){
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, level);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2);
}

void fadeOutBackLigth(){
    ledc_set_fade_with_time(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, 0x00, 1000);
    ledc_fade_start(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, LEDC_FADE_NO_WAIT);
}

void fadeInBackLigth(uint8_t target_brigtness){
    ledc_set_fade_with_time(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, target_brigtness, 1000);
    ledc_fade_start(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_2, LEDC_FADE_NO_WAIT);
}
