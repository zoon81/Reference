#include "node_bank.h"

#include "esp_system.h"
#include "nvs_flash.h"
#include "nvs.h"
#include <string.h>

#define NODEBANK_NAMESPACE  "nodebank"
#define NODECOUNT_KEY       "nodecount"
#define NODEDATA_KEY        "nodedata"

struct node_s{
    uint8_t subaddress;                             // Node subaddress 
    char name[NODE_NAME_MAX_LEN];                   // Node name
};
typedef struct node_s node_t;

struct node_prop_s{
    uint8_t status;                                 // Status of a node See NODE_STATUS_* defines
    uint8_t signal;                                 // Calculated radio link quality of a node
    uint16_t battery_voltage;                       // Battery Voltage of a node 
    uint8_t battery_percent;                        // Remaining battery capacity in %
    uint8_t error_code;
};
typedef struct node_prop_s node_prop_t;

struct nodebank_s{
    uint8_t count;
    uint8_t last_node_subaddress;
    bool last_pair_is_successfull;
    node_t *nodes;
    node_prop_t *node_props;

};
typedef struct nodebank_s nodebank_t;

nodebank_t nodebank;
uint8_t active_node_index;
void (*commitChanges)();
void nodebank_commit_default();

esp_err_t nodebank_loadData();
esp_err_t nodebank_storeData();

void nodebank_init(void (*callback) ())
{
    if(callback == NULL){
        commitChanges = nodebank_commit_default;
    } else {
        commitChanges = callback;

    }
    nodebank.count = 0;
    nodebank.last_node_subaddress = 0;
    nodebank.last_pair_is_successfull = false;

    esp_err_t err = nvs_flash_init();
    if (err == ESP_ERR_NVS_NO_FREE_PAGES || err == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        // NVS partition was truncated and needs to be erased
        // Retry nvs_flash_init
        ESP_ERROR_CHECK(nvs_flash_erase());
        err = nvs_flash_init();
    }
    ESP_ERROR_CHECK( err );
    if(err == ESP_OK){
        nodebank_loadData();
    }
}

void nodebank_addPairedNode(const char * node_name)
{
    nodebank.nodes = (node_t *) heap_caps_realloc(nodebank.nodes, (sizeof(node_t) * (nodebank.count + 1)), MALLOC_CAP_8BIT);
    nodebank.node_props = (node_prop_t *) heap_caps_realloc(nodebank.node_props, (sizeof(node_prop_t) * (nodebank.count + 1)), MALLOC_CAP_8BIT);
    // Look for the next free subaddress, this is not an incremental sequence, We pick up the smallest free number
    
    nodebank.nodes[nodebank.count].subaddress = nodebank_getFreeSubAddress();
    sprintf(nodebank.nodes[nodebank.count].name, "%s", node_name);
    nodebank.node_props[nodebank.count].status = NODE_STATUS_CONNECTED;
    nodebank.node_props[nodebank.count].signal = 0;
    nodebank.node_props[nodebank.count].battery_voltage = 0;
    nodebank.node_props[nodebank.count].battery_percent = 0;
    nodebank.node_props[nodebank.count].error_code = 0;
    nodebank.count++;
    nodebank_storeData();
}

uint8_t nodebank_getFreeSubAddress(){
    uint8_t subaddress = 0;
    while( subaddress <  NODE_MAX_NODES_COUNT){
        int8_t node_count = nodebank_getNodeCount();
        while(node_count > 0){
            node_count--;
            if(subaddress == nodebank.nodes[node_count].subaddress){
                // This subbaddress is in use,break the loop
                node_count = -1;
            }
        }
        // Check for the upper loop result
        // If the loop went trougth all the elements and did not found a match
        // then the subaddress is free to use
        if(node_count == 0){
            break;
        } else {
            subaddress++;
        }
    }

    return subaddress;
}

void nodebank_setLastPairResult(bool result)
{
    nodebank.last_pair_is_successfull = result;
}

bool nodebank_isLastPairSuccess(){
    return nodebank.last_pair_is_successfull;
}

esp_err_t nodebank_storeData(){
    nvs_handle_t my_handle;
    esp_err_t err;

    err = nvs_open(NODEBANK_NAMESPACE, NVS_READWRITE, &my_handle);
    if (err != ESP_OK) return err;

    // Write
    err = nvs_set_u8(my_handle, NODECOUNT_KEY, nodebank.count);
    if (err != ESP_OK) return err;
    err = nvs_set_blob(my_handle, NODEDATA_KEY, nodebank.nodes, nodebank.count * sizeof(node_t));
    if (err != ESP_OK) return err;

    err = nvs_commit(my_handle);
    if (err != ESP_OK) return err;

    // Close
    nvs_close(my_handle);
    return ESP_OK;
}

esp_err_t nodebank_loadData(){
    nvs_handle_t my_handle;
    esp_err_t err;

    err = nvs_open(NODEBANK_NAMESPACE, NVS_READONLY, &my_handle);
    if (err != ESP_OK) return err;

    // Read
    err = nvs_get_u8(my_handle, NODECOUNT_KEY, &(nodebank.count));
    if (err != ESP_OK) return err;
    if(nodebank.count > 0){
        nodebank.nodes = (node_t *) heap_caps_realloc(nodebank.nodes, (sizeof(node_t) * nodebank.count), MALLOC_CAP_8BIT);
        size_t blob_size = nodebank.count * sizeof(node_t);
        err = nvs_get_blob(my_handle, NODEDATA_KEY, nodebank.nodes, &blob_size);
        if (err != ESP_OK) return err;
        nodebank.node_props = (node_prop_t *) heap_caps_realloc(nodebank.node_props, (sizeof(node_prop_t) * nodebank.count), MALLOC_CAP_8BIT);
        // Fill up
        uint8_t i;
        for(i = 0; i < nodebank.count; i++){
            nodebank.node_props[i].battery_percent = 0;
            nodebank.node_props[i].battery_voltage = 0;
            nodebank.node_props[i].signal = 0;
            nodebank.node_props[i].status = NODE_STATUS_DISCONNECTED;
        }
    }
    

    // Close
    nvs_close(my_handle);
    return ESP_OK;
}

void nodebank_deleteNodeByIndex(uint8_t index){
    node_t *tmp_node_db = (node_t *) heap_caps_malloc( (sizeof(node_t) * (nodebank.count - 1)), MALLOC_CAP_8BIT);
    // node_prop_t *tmp_node_prop_db = (node_prop_t *) heap_caps_realloc(tmp_node_prop_db, (sizeof(node_prop_t) * nodebank.count), MALLOC_CAP_8BIT);
    uint8_t node_counter = 0;
    uint8_t nodebank_index = 0;
    while(node_counter < nodebank_getNodeCount()){
        if(node_counter != index){
            // Static node data
            tmp_node_db[nodebank_index].subaddress = nodebank.nodes[node_counter].subaddress;
            strcpy(tmp_node_db[nodebank_index].name, nodebank.nodes[node_counter].name);
            nodebank_index++;
        }
        node_counter++;
    }
    heap_caps_free(nodebank.nodes);
    nodebank.count--;
    nodebank.nodes = tmp_node_db;
    nodebank_storeData();
}
/**
 * @brief Get node subaddress by its position in nodebank
 * 
 * @param node_index node index in nodebank
 * @return uint8_t Subaddress of the node
 */

uint8_t nodebank_getNodeSubAddresbyIndex(uint8_t node_index){
    return nodebank.nodes[node_index].subaddress;
}

uint8_t nodebank_getNodeCount(){
    return nodebank.count;                      
}

uint8_t nodebank_getStoredNodesCount(){
    return nodebank.count == 0 ? 0 : nodebank.count - 1; // We allocated memory for upcomming node too, so there is only nodebank.count - 1 nodes on nodebank 
}

/**
 * @brief Pick a node as a default node called active node
 * This function is used by radio callback functions to set some status flags
 * @param node_index 
 */
void nodebank_selectActiveNode(uint8_t node_index){
    active_node_index = node_index;
}
// This function is used by the UI to identify a node by its name
uint8_t nodebank_getNodeByName(char *node_name){
    uint8_t node_count = nodebank.count;
    uint8_t retval = 0;
    while(node_count--){
        if( strcmp(node_name, nodebank.nodes[node_count].name) == 0){
            retval = node_count;
            node_count = 0;
        }
    }
    return retval;
}

// This function is used by the UI to get the node name by its index
void nodebank_getNodeNamebyIndex(uint8_t index, char *buffer){
    strcpy(buffer, nodebank.nodes[index].name);
}

uint8_t nodebank_getActiveNodeSubAddress(){
    return nodebank.nodes[active_node_index].subaddress;
}

void nodebank_setActiveNodeStatus(uint8_t status){
    nodebank.node_props[active_node_index].status = status;
}

uint8_t nodebank_getActiveNodeStatus(){
    return nodebank.node_props[active_node_index].status;
}

void nodebank_setActiveNodeBatteryVoltage(uint16_t battery_voltage){
    nodebank.node_props[active_node_index].battery_voltage = battery_voltage;
}

uint16_t nodebank_getActiveNodeBatteryVoltage(){
    return nodebank.node_props[active_node_index].battery_voltage;
}

void nodebank_setActiveNodeBatteryPercent(uint8_t battery_percent){
    nodebank.node_props[active_node_index].battery_percent = battery_percent;
}

uint8_t nodebank_getActiveNodeBatteryPercent(){
    return nodebank.node_props[active_node_index].battery_percent;
}

void nodebank_setActiveNodeSignal(uint8_t signal){
    nodebank.node_props[active_node_index].signal = signal;
}

uint8_t nodebank_getActiveNodeSignal(){
    return nodebank.node_props[active_node_index].signal;
}
// Name should be 12 character
void nodebank_setActiveNodeName(char *name){
    memcpy(name, nodebank.nodes[active_node_index].name, 12);
}

void nodebank_getActiveNodeName(char *buffer){
    memcpy(buffer, nodebank.nodes[active_node_index].name, 12);
}

void nodebank_setActiveNodeErrorCode( uint8_t err ){
    nodebank.node_props[active_node_index].error_code = err;
}

uint8_t nodebank_getActiveNodeErrorCode(){
    return nodebank.node_props[active_node_index].error_code;
}

void nodebank_deletePairedNodes(){
    nodebank.count = 0;
    nodebank_storeData();
    nodebank_commitChanges();
}

// This function trigger the homepage cache update
void nodebank_commitChanges(){
    commitChanges();
}

void nodebank_commit_default(){

}

uint8_t nodebank_getConnectedNodeCount(){
    uint8_t i, connected_nodes = 0;
    for(i = 0; i < nodebank.count; i++){
        if(nodebank.node_props[i].status == NODE_STATUS_CONNECTED){
            connected_nodes++;
        }
    }
    return connected_nodes;
}





